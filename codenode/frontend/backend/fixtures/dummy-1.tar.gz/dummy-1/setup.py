import os
try:
    from setuptools import setup 
except ImportError:
    from distutils.core import setup



setup(
    name='dummy',
    version='1',
    packages=['dummy'],
)
